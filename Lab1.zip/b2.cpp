#include<iostream>
using namespace std;
int main(){
    struct Student
    {
        char name [30];
        char class [10];
        float mMath;
        float mPhysical;
    };  
    
}